In order to run this program on the HPC cluster, use the command

```
sbatch run-tests.sh
```

When the tests are complete, the output will be printed to a file called `primeTest.out`. You can view the contents of this file by issuing the command

```
cat primeTest.out
```
