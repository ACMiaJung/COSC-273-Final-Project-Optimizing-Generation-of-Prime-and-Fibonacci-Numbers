public class ParallelPrimes {

    // replace this string with your team name
    public static final String TEAM_NAME = "baseline";

    public static void optimizedPrimes(int[] primes) {
	
	// replace this with your optimized method
	Primes.baselinePrimes(primes);
	
    }
}
